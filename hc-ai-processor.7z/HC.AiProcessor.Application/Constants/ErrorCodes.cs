﻿namespace HC.AiProcessor.Application.Constants;

internal static class ErrorCodes
{
    public const string InsufficientQuotaError = "INSUFFICIENT_QUOTA_ERROR";
    public const string EmptyAiAgentResponseError = "EMPTY_AI_AGENT_RESPONSE_ERROR";
    public const string InvalidAiAgentResponseError = "INVALID_AI_AGENT_RESPONSE_ERROR";
    public const string InputProcessingError = "INPUT_PROCESSING_ERROR";
    public const string RequestFailedError = "REQUEST_FAILED_ERROR";
    public const string BatchFailedError = "BATCH_FAILED_ERROR";
    public const string UnknownError = "UNKNOWN_ERROR";
}
