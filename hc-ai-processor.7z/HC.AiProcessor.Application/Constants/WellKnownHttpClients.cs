﻿namespace HC.AiProcessor.Application.Constants;

internal static class WellKnownHttpClients
{
    public const string AiClient = "AiClient";

    public const string SerperClient = "SerperClient";
    
    public const string DeWatermarkClient = "DeWatermarkClient";

    public const string ClaidAiClient = "ClaidAiClient";
}
