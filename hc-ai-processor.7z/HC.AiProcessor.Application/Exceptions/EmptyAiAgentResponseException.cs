﻿using HC.AiProcessor.Application.Constants;

namespace HC.AiProcessor.Application.Exceptions;

public class EmptyAiAgentResponseException() : AiProcessorException(ErrorCodes.EmptyAiAgentResponseError);
