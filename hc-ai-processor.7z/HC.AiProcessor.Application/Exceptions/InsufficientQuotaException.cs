﻿using HC.AiProcessor.Application.Constants;

namespace HC.AiProcessor.Application.Exceptions;

public class InsufficientQuotaException : AiProcessorException
{
    public InsufficientQuotaException() : base(ErrorCodes.InsufficientQuotaError)
    {
    }

    public InsufficientQuotaException(string message) : base(ErrorCodes.InsufficientQuotaError, message)
    {
    }
}
