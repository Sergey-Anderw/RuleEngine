﻿namespace HC.AiProcessor.Application.Exceptions;

public class AiProcessorException : Exception
{
    public string Code { get; init; }

    public AiProcessorException(string code)
    {
        Code = code;
    }

    public AiProcessorException(string code, string message) : base(message)
    {
        Code = code;
    }

    public AiProcessorException(string code, string message, Exception innerException) : base(message, innerException)
    {
        Code = code;
    }
}
