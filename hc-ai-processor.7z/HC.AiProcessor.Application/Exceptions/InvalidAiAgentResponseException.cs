﻿using HC.AiProcessor.Application.Constants;

namespace HC.AiProcessor.Application.Exceptions;

public class InvalidAiAgentResponseException : AiProcessorException
{
    public InvalidAiAgentResponseException() : base(ErrorCodes.InvalidAiAgentResponseError)
    {
    }

    public InvalidAiAgentResponseException(string message) : base(ErrorCodes.InvalidAiAgentResponseError, message)
    {
    }

    public InvalidAiAgentResponseException(string message, Exception innerException)
        : base(ErrorCodes.InvalidAiAgentResponseError, message, innerException)
    {
    }
}
