﻿using System.Diagnostics.CodeAnalysis;
using System.Text.Json;
using HC.AiProcessor.Application.Exceptions;
using JsonRepairUtils;

namespace HC.AiProcessor.Application.Common;

public static class AiAgentResponseHelper
{
    [return: NotNullIfNotNull(nameof(content))]
    public static T ToObjectFromJson<T>(string? content, JsonSerializerOptions? options = null) where T : class
    {
        options ??= JsonSettingsExtensions.Default;

        if (string.IsNullOrWhiteSpace(content))
            throw new EmptyAiAgentResponseException();

        string json = NormalizeJson(content);

        if (string.IsNullOrWhiteSpace(json))
            throw new EmptyAiAgentResponseException();

        try
        {
            return Deserialize<T>(json, options);
        }
        catch (JsonException firstJsonException)
        {
            try
            {
                string repairedJson = new JsonRepair().Repair(json);

                try
                {
                    return Deserialize<T>(repairedJson, options);
                }
                catch (JsonException secondJsonException)
                {
                    throw new InvalidAiAgentResponseException(secondJsonException.Message, secondJsonException)
                    {
                        Data = { { "OriginalJsonException", firstJsonException } }
                    };
                }
            }
            catch (JsonRepairError jsonRepairError)
            {
                throw new InvalidAiAgentResponseException(firstJsonException.Message, firstJsonException)
                {
                    Data = { { "JsonRepairError", jsonRepairError } }
                };
            }
        }
    }

    private static T Deserialize<T>(string json, JsonSerializerOptions options) where T : class
    {
        return JsonSerializer.Deserialize<T>(json, options) ??
               throw new InvalidAiAgentResponseException("Deserialized json is null");
    }

    private static string NormalizeJson(string content)
    {
        const string startTrim = "```json";
        int index = content.IndexOf(startTrim, StringComparison.InvariantCultureIgnoreCase);
        string normalized = index != 0 ? content : content.Remove(index, startTrim.Length);

        return normalized.Trim('`').Trim();
    }
}
