﻿using System.Net.Http.Headers;
using System.Text.Json;
using HC.AiProcessor.Application.Constants;
using HC.Packages.Common.Contracts.V1;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;

namespace HC.AiProcessor.Application.Clients;

public class DeWatermarkAiClient(
    IHttpClientFactory httpClientFactory,
    ILogger<SerperClient> logger)
{
    private readonly HttpClient _httpClient = httpClientFactory.CreateClient(WellKnownHttpClients.DeWatermarkClient);
    private const string EndPoint = "/api/object_removal/v1/erase_watermark";

    public async Task<byte[]> CleanUpWatermark(byte[] image, string imageName, string mimeType, CancellationToken cancellationToken = default)
    {
        using var form = new MultipartFormDataContent();
        AddImage(form, image, imageName, mimeType);
        form.Add(new StringContent("false"), "remove_text");

        using (logger.BeginScope("The DeWatermark API processing for {imageName}", imageName))
        {
            HttpResponseMessage response;
            try
            {
                response = await _httpClient.PostAsync(EndPoint, form, cancellationToken);
            }
            catch (Exception ex)
            {
                logger.LogWarning(ex, "Connection issue with DeWatermark API : {Message}", ex.Message);
                throw new MicroserviceApiException(
                    $"Error with connection to the DeWatermark API: {ex.Message}",
                    StatusCodes.Status502BadGateway,
                    EndPoint,
                    "DeWatermark API",
                    null);
            }
    
            if (!response.IsSuccessStatusCode)
            {
                var errorContent = await response.Content.ReadAsStringAsync(cancellationToken);
                logger.LogWarning("The DeWatermark API returned an error {StatusCode}: {ErrorContent}",
                    (int)response.StatusCode, errorContent);
                throw new MicroserviceApiException(
                    $"The DeWatermark API returned an error {(int)response.StatusCode}: {errorContent}",
                    (int)response.StatusCode,
                    EndPoint,
                    "DeWatermark API",
                    null);
            }

            await using var stream = await response.Content.ReadAsStreamAsync(cancellationToken);
            var result =
                await JsonSerializer.DeserializeAsync<EraseResponse>(stream, cancellationToken: cancellationToken);
            return result!.EditedImage.ConvertToBytes();
        }
    }
    
    private static void AddImage(MultipartFormDataContent form, byte[] bytes, string fileName, string contentType)
    {
        HttpContent content = new ByteArrayContent(bytes);
        content.Headers.ContentType = new MediaTypeHeaderValue(contentType);
        form.Add(content, "original_preview_image", fileName);
    }
    
    private sealed class EraseResponse
    {
        [JsonPropertyName("edited_image")]
        public EditedImage EditedImage { get; init; } = null!;

        [JsonPropertyName("event_id")]
        public string EventId { get; init; } = null!;

        [JsonPropertyName("session_id")]
        public string SessionId { get; init; } = null!;
    }

    private sealed class EditedImage
    {
        [JsonPropertyName("image")]
        public string ImageBase64 { get; init; } = null!;

        [JsonPropertyName("image_id")]
        public string ImageId { get; init; } = null!;

        [JsonPropertyName("mask")]
        public string MaskBase64 { get; init; } = null!;

        [JsonPropertyName("watermark_mask")]
        public string WatermarkMaskBase64 { get; init; } = null!;
        
        public byte[] ConvertToBytes()
        {
            var base64String = ImageBase64;
            if (base64String.Contains(','))
            {
                base64String = base64String.Split(',')[1];
            }
    
            var imageBytes = Convert.FromBase64String(base64String);
            return imageBytes;
        }
    }
}
