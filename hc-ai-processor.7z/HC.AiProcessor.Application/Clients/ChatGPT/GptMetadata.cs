namespace HC.AiProcessor.Application.Clients.ChatGPT;
public class GPTMetadata
{
    public string Url { get; set; } = null!;
    public string? Body { get; set; }

    public LimitData RequestLimit { get; set; } = null!;
    public LimitData TokenLimit { get; set; } = null!;
}


public class LimitData
{
    public long RemainingCount { get; set; }
    public TimeSpan ResetAfter { get; set; }
}
