namespace HC.AiProcessor.Application.Clients.ChatGPT;

public class GPTLimitException : Exception
{
    public GPTMetadata Request { get; init; }
    public string Provider { get; init; }

    public GPTLimitException(
        string provider,
        GPTMetadata request,
        string? message = null,
        Exception? inner = null
        ) : base(message, inner)
    {
        Request = request;
        Provider = provider;
    }
}
