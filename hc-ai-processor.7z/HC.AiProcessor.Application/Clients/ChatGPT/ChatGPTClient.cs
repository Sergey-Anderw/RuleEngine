﻿using System.Text.Json;
using System.Text.Json.Nodes;
using System.Net.Http.Headers;
using HC.AiProcessor.Application.Clients.ChatGPT;
using Microsoft.Extensions.Logging;
using System.Net.Http.Json;
using System.Text.RegularExpressions;
using HC.AiProcessor.Application.Common;
using HC.AiProcessor.Application.Models;

// using SharpToken;

namespace HC.AiProcessor.Application.Clients.ChatGPT;

public partial class ChatGPTClient : IDisposable
{
    private readonly IHttpClientFactory _httpClientFactory;
    private readonly ILogger<ChatGPTClient> _logger;
    private ChatGptConfig? _aiSettings;
    private HttpClient? _httpClient;
    // private GptEncoding _tokenEncoding = null!;

    public ChatGPTClient(
        IHttpClientFactory httpClientFactory,
        ILogger<ChatGPTClient> logger)
    {
        _httpClientFactory = httpClientFactory;
        _logger = logger;
    }

    public void Dispose()
    {
        _httpClient?.Dispose();
        GC.SuppressFinalize(this);
    }

    public void Configure(ChatGptConfig config)
    {
        _aiSettings = config;
        _httpClient = CreateClient();
        //_tokenEncoding = GptEncoding.GetEncodingForModel(config.Model);
    }

    // public int GetTokenCount(string input)
    // {
    //     return _tokenEncoding.CountTokens(input);
    // }

    public async Task<(JsonObject?, GPTMetadata)> AskAsync(IReadOnlyCollection<string> requests, string? setup, CancellationToken ct = default)
    {
        if (_aiSettings is null || _httpClient is null)
            throw new ArgumentException("ChatGPT client was not configured");

        var messages = new List<ChatGPTChatMessage>();
        if (!string.IsNullOrEmpty(setup))
        {
            messages.Add(new ChatGPTChatMessage
            {
                Role = "system",
                Content = setup
            });
        }

        messages.AddRange(
            requests.Select(x => new ChatGPTChatMessage
            {
                Role = "user",
                Content = x
            })
        );

        var requestData = new ChatGPTCompletionRequest
        {
            Model = _aiSettings.Model,
            Messages = messages.ToArray()
        };

        var meta = new GPTMetadata
        {
            Url = _aiSettings.ChatCompletionEndpoint,
            Body = JsonSerializer.Serialize(requestData, JsonSettingsExtensions.Default)
        };

        var response = await _httpClient
            .PostAsJsonAsync(_aiSettings.ChatCompletionEndpoint, requestData, JsonSettingsExtensions.Default, ct);

        meta.RequestLimit = GetRequestsLimitState(response.Headers);
        meta.TokenLimit = GetTokensLimitState(response.Headers);

        var contentStr = await response.Content.ReadAsStringAsync(ct);
        if (!response.IsSuccessStatusCode)
            throw new GPTErrorException(
                "ChatGPT",
                meta,
                contentStr,
                (int)response.StatusCode,
                "Chat completion failed"
            );

        return (
            JsonSerializer.Deserialize<JsonObject>(contentStr, JsonSettingsExtensions.Default),
            meta
        );
    }

    public async Task<(JsonObject?, GPTMetadata)> AskAsync(IReadOnlyCollection<ChatGPTChatMessage> messages, CancellationToken ct = default)
    {
        if (_aiSettings is null || _httpClient is null)
            throw new ArgumentException("ChatGPT client was not configured");

        var requestData = new ChatGPTCompletionRequest
        {
            Model = _aiSettings.Model,
            Messages = messages.ToArray()
        };

        var meta = new GPTMetadata
        {
            Url = _aiSettings.ChatCompletionEndpoint,
            Body = JsonSerializer.Serialize(requestData, JsonSettingsExtensions.Default)
        };

        var response = await _httpClient
            .PostAsJsonAsync(_aiSettings.ChatCompletionEndpoint, requestData, JsonSettingsExtensions.Default, ct);

        meta.RequestLimit = GetRequestsLimitState(response.Headers);
        meta.TokenLimit = GetTokensLimitState(response.Headers);

        var contentStr = await response.Content.ReadAsStringAsync(ct);
        if (!response.IsSuccessStatusCode)
        {
            if (response.StatusCode == System.Net.HttpStatusCode.TooManyRequests)
            {
                throw new GPTLimitException(
                    "ChatGPT",
                    meta
                );
            }
            else
                throw new GPTErrorException(
                    "ChatGPT",
                    meta,
                    contentStr,
                    (int)response.StatusCode,
                    "Chat completion failed"
                );
        }

        return (
            JsonSerializer.Deserialize<JsonObject>(contentStr, JsonSettingsExtensions.Default),
            meta
        );
    }

    private HttpClient CreateClient()
    {
        var client = _httpClientFactory.CreateClient("AIClient");
        client.Timeout = TimeSpan.FromSeconds(_aiSettings!.RequestTimeout);
        client.DefaultRequestHeaders.Clear();
        client.DefaultRequestHeaders.Add("accept", "application/json");
        client.DefaultRequestHeaders.Add("Authorization", "Bearer " + _aiSettings!.ApiKey);
        return client;
    }

    private LimitData GetRequestsLimitState(HttpResponseHeaders headers)
    {
        long? remainingRequestCount = null;
        TimeSpan? resetTime = null;
        if (headers.TryGetValues("x-ratelimit-remaining-requests", out var remainingRequest)
            && long.TryParse(remainingRequest.First(), out var remainingRequestVal))
        {
            remainingRequestCount = remainingRequestVal;
        }

        if (headers.TryGetValues("x-ratelimit-reset-requests", out var resetReq))
        {
            resetTime = ParseTime(resetReq.First());
        }

        return new LimitData { RemainingCount = remainingRequestCount ?? 0, ResetAfter = resetTime ?? TimeSpan.Zero };
    }

    private LimitData GetTokensLimitState(HttpResponseHeaders headers)
    {
        long? remainingTokenCount = null;
        TimeSpan? resetTime = null;
        if (headers.TryGetValues("x-ratelimit-remaining-tokens", out var remainingTokens)
            && long.TryParse(remainingTokens.First(), out var remainingTokensVal))
        {
            remainingTokenCount = remainingTokensVal;
        }

        if (headers.TryGetValues("x-ratelimit-reset-tokens", out var resetReq))
        {
            resetTime = ParseTime(resetReq.First());
        }

        return new LimitData { RemainingCount = remainingTokenCount ?? 0, ResetAfter = resetTime ?? TimeSpan.Zero };
    }

    private TimeSpan ParseTime(string time)
    {
        var regex = GptHeaderResetTimeRegex();

        var matches = regex.Matches(time);

        int ms = 0;
        int s = 0;
        int m = 0;
        int h = 0;

        foreach (var match in matches.Reverse())
        {
            if (match.Groups.Count != 4)
                throw new Exception($"Invalid Gpt header value format - '{time}'");
            var value = int.Parse(match.Groups[2].Value);
            switch (match.Groups[3].Value)
            {
                case "ms": ms = value; break;
                case "s": s = value; break;
                case "m": m = value; break;
                case "h": h = value; break;
                default: throw new Exception($"Invalid Gpt header value format - '{time}'");
            }
        }

        return new TimeSpan(0, h, m, s, ms);
    }

    [GeneratedRegex("(([0-9]+)([hms]+))")]
    private static partial Regex GptHeaderResetTimeRegex();
}
