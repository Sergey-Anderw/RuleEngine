namespace HC.AiProcessor.Application.Clients.ChatGPT;

public class GPTErrorException : Exception
{
    public GPTMetadata Request { get; init; }
    public string RawResult { get; init; }
    public int ResultCode { get; init; }
    public string Provider { get; init; }

    public GPTErrorException(
        string provider,
        GPTMetadata request,
        string rawResult,
        int resultCode,
        string? message = null,
        Exception? inner = null
        ) : base(message, inner)
    {
        Request = request;
        Provider = provider;
        RawResult = rawResult;
        ResultCode = resultCode;
    }
}
