namespace HC.AiProcessor.Application.Clients.ChatGPT;

public class ChatGPTExtarctionSettings
{
    //public int? MaxTokens { get; set; }
    public string? SetupRequest { get; set; }
    public string Prompt { get; set; } = null!;

    [Obsolete("Use " + nameof(Prompt) + " instead.")]
    public string Promt
    {
        get => Prompt;
        set => Prompt = value;
    }

    public string EntryFormat { get; set; } = "";
    public string EntrySeparator { get; set; } = "";
    public string InputDelimiter { get; set; } = "\n";
    public string RequestDelimiter { get; set; } = "\n";
}
