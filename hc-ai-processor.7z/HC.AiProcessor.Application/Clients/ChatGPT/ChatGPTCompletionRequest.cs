namespace HC.AiProcessor.Application.Clients.ChatGPT;

public class ChatGPTChatMessage
{
    [JsonPropertyName("role")]
    public string Role { get; set; } = "user";
    [JsonPropertyName("content")]
    public string Content { get; set; } = null;
}

public class ChatGPTCompletionRequest
{
    [JsonPropertyName("model")]
    public string Model { get; set; }
    [JsonPropertyName("messages")]
    public ChatGPTChatMessage[] Messages { get; set; }
    [JsonPropertyName("temperature")]
    public double? Temperature { get; set; }
    [JsonPropertyName("top_p")]
    public double? TopP { get; set; }
    [JsonPropertyName("max_tokens")]
    public int? MaxTokens { get; set; }
}
