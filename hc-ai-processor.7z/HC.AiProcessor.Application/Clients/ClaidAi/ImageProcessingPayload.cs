﻿using HC.Packages.AiProcessor.V1.Models;

namespace HC.AiProcessor.Application.Clients.ClaidAi;

/// <summary>
/// Read more about ClaidAi payload here https://docs.claid.ai/image-editing-api/api-reference
/// </summary>
/// <param name="Input">Full image url to transform</param>
public record ImageProcessingPayload(string Input)
{
    public required Operations Operations { get; init; }
    public OutputConfiguration? Output { get; set; }

    public static ImageProcessingPayload Create(AiProcessorImageTransformationRequest request)
    {
        ArgumentNullException.ThrowIfNull(request);
        ArgumentNullException.ThrowIfNull(request.ImageUrl);

        var operations = new Operations();

        if (request.Background != null)
        {
            operations.Background =
                new BackgroundOperation(request.Background.Colour, new RemoveOption(request.Background.Clipping));
        }
        
        if (request.Restoration != null)
        {
            operations.Restorations = new RestorationOperation("smart_enhance");
        }

        if (request.ChangeSize != null)
        {
            operations.Resizing = new ResizingOperation();
            if (request.ChangeSize.Width != null)
            {
                operations.Resizing.Width = request.ChangeSize.Width;
            }
            else
            {
                operations.Resizing.Width = "auto";
            }

            if (request.ChangeSize.Height != null)
            {
                operations.Resizing.Height = request.ChangeSize.Height;
            }
            else
            {
                operations.Resizing.Height = "auto";
            }

            if (!string.IsNullOrEmpty(request.ChangeSize.Crop))
            {
                operations.Resizing.Fit = new ResizingFitOptions { Crop = request.ChangeSize.Crop };
            } else if (!string.IsNullOrEmpty(request.ChangeSize.Fit))
            {
                operations.Resizing.Fit = request.ChangeSize.Fit;
            }
        }

        var result = new ImageProcessingPayload(request.ImageUrl)
        {
            Operations = operations
        };

        if (result.Operations.Background != null)
        {
            result.Output = new OutputConfiguration("png");
        }

        if (!string.IsNullOrEmpty(request.Padding))
        {
            result.Operations.Padding = request.Padding;
        }

        return result;
    }
}

public record Operations
{
    public BackgroundOperation? Background { get; set; }
    public RestorationOperation? Restorations { get; set; }
    public ResizingOperation? Resizing { get; set; }
    
    public string? Padding { get; set; }
}

public record BackgroundOperation(string Color, RemoveOption Remove);

public record RemoveOption(bool Clipping);

public record RestorationOperation(string Upscale);

public record ResizingOperation
{
    
    private object? _width;
    private object? _height;

    public object Width
    {
        get => _width ?? "auto";
        set => _width = value?.ToString() == "auto" ? "auto" :
            int.TryParse(value?.ToString(), out var result) ? result : "auto";
    }

    public object Height
    {
        get => _height ?? "auto";
        set => _height = value?.ToString() == "auto" ? "auto" :
            int.TryParse(value?.ToString(), out var result) ? result : "auto";
    }
    
    public object? Fit { get; set; }
}

public record ResizingFitOptions
{
    public string Crop { get; set; } = "smart";
}

public record OutputConfiguration(string Format);
