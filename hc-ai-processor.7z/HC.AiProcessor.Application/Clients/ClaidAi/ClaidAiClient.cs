﻿using System.Text;
using System.Text.Json;
using HC.AiProcessor.Application.Common;
using HC.AiProcessor.Application.Constants;
using HC.Packages.Common.Contracts.V1;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;

namespace HC.AiProcessor.Application.Clients.ClaidAi;

public class ClaidAiClient(
    IHttpClientFactory httpClientFactory,
    ILogger<ClaidAiClient> logger)
{
    private readonly HttpClient _httpClient = httpClientFactory.CreateClient(WellKnownHttpClients.ClaidAiClient);
    private const string EstimationEndpoint = "/v1-beta1/estimation";
    private const string EditEndpoint = "/v1-beta1/image/edit";

    public async Task<ClaidAiEstimateResponse> Estimate(string imageUrl, CancellationToken cancellationToken)
    {
        ArgumentException.ThrowIfNullOrEmpty(imageUrl, nameof(imageUrl));

        var payload = new
        {
            input = imageUrl,
            options = new
            {
                image_quality = true,
                moderation = new
                {
                    paddings = true
                }
            }
        };

        return await ProcessRequest<ClaidAiEstimateResponse>(imageUrl, EstimationEndpoint, payload, cancellationToken);
    }
    
    public async Task<ImageProcessingResponse> Transform(
        ImageProcessingPayload payload, 
        CancellationToken cancellationToken)
    => await ProcessRequest<ImageProcessingResponse>(payload.Input, EditEndpoint, payload, cancellationToken);

    private async Task<T> ProcessRequest<T>(string imageUrl, string url, object payload,
        CancellationToken cancellationToken)
    {
        using (logger.BeginScope("Claid AI processing for {ImageUrl}", imageUrl))
        {
            var json = JsonSerializer.Serialize(payload, JsonSettingsExtensions.Default);
            using var content = new StringContent(json, Encoding.UTF8, "application/json");
            HttpResponseMessage response;
            try
            {
                response = await _httpClient.PostAsync(url, content, cancellationToken);
            }
            catch (Exception ex)
            {
                logger.LogWarning(ex, "Connection issue with Claid AI API : {Message}", ex.Message);
                throw new MicroserviceApiException(
                    $"Error with connection to the Claid AI API: {ex.Message}",
                    StatusCodes.Status502BadGateway,
                    url,
                    "Claid AI API",
                    null);
            }

            if (!response.IsSuccessStatusCode)
            {
                var errorContent = await response.Content.ReadAsStringAsync(cancellationToken);
                logger.LogWarning("The Claid AI API returned an error {StatusCode}: {ErrorContent}",
                    (int)response.StatusCode, errorContent);

                throw new MicroserviceApiException(
                    $"The Claid AI API returned an error {(int)response.StatusCode}: {errorContent}",
                    (int)response.StatusCode,
                    url,
                    "Claid AI API",
                    null);
            }

            await using var stream = await response.Content.ReadAsStreamAsync(cancellationToken);
            var results = await JsonSerializer.DeserializeAsync<T>(stream, cancellationToken: cancellationToken);
            return results ?? throw new JsonException("Failed to deserialize response");
        }
    }
}
