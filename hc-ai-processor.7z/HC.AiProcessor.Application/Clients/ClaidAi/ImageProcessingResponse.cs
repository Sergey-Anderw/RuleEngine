﻿using HC.Packages.AiProcessor.V1.Models;

namespace HC.AiProcessor.Application.Clients.ClaidAi;

public record ImageProcessingResponse
{
    [JsonPropertyName("data")]
    public ImageProcessingData Data { get; init; } = null!;
}

public record ImageProcessingData
{
    [JsonPropertyName("input")]
    public ImageInfo Input { get; init; } = null!;

    [JsonPropertyName("output")]
    public OutputImageInfo Output { get; init; } = null!;

}
public record ImageInfo
{
    [JsonPropertyName("ext")]
    public string Extension { get; init; } = null!;

    [JsonPropertyName("mps")]
    public double Mps { get; init; }

    [JsonPropertyName("mime")]
    public string MimeType { get; init; } = null!;

    [JsonPropertyName("width")]
    public int Width { get; init; }

    [JsonPropertyName("format")]
    public string Format { get; init; } = null!;

    [JsonPropertyName("height")]
    public int Height { get; init; }
}

public record OutputImageInfo : ImageInfo
{
    [JsonPropertyName("tmp_url")]
    public string TemporaryUrl { get; init; } = null!;
}

public static class ImageProcessingResponseExtensions
{
    public static AiProcessorImageTransformationResponse ToTransformResponse(this ImageProcessingResponse response) =>
        new(
            response.Data.Output.TemporaryUrl,
            GetFileNameFromUrl(response.Data.Output.TemporaryUrl),
            response.Data.Output.Extension,
            response.Data.Output.Mps,
            response.Data.Output.MimeType,
            response.Data.Output.Width,
            response.Data.Output.Height,
            response.Data.Output.Format);

    private static string GetFileNameFromUrl(string url)
    {
        var uri = new Uri(url);
        var fileName = Path.GetFileName(uri.LocalPath);
        if (!string.IsNullOrEmpty(fileName))
        {
            return fileName;
        }
    
        var segments = uri.Segments;
        if (segments.Length <= 0) return uri.Host;
        var lastSegment = segments[^1].TrimEnd('/');
        return !string.IsNullOrEmpty(lastSegment) ? lastSegment : uri.Host;
    }
}

