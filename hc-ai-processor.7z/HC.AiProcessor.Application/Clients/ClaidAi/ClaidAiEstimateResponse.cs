﻿namespace HC.AiProcessor.Application.Clients.ClaidAi;

public record ClaidAiEstimateResponse
{
    [JsonPropertyName("data")]
    public ImageQualityData Data { get; init; }  = null!;
}

public record ImageQualityData
{
    [JsonPropertyName("image_quality")]
    public QualityMetrics ImageQuality { get; init; } = null!;
    
    [JsonPropertyName("moderation")]
    public ModerationInfo Moderation { get; init; } = null!;
}

public record QualityMetrics
{
    [JsonPropertyName("exposure")]
    public double Exposure { get; init; }
    [JsonPropertyName("saturation")]
    public double Saturation { get; init; }
    [JsonPropertyName("contrast")]
    public double Contrast { get; init; }
    [JsonPropertyName("sharpness")]
    public double Sharpness { get; init; }
    
    [JsonPropertyName("defocus_score")]
    public double DefocusScore { get; init; }
    
    [JsonPropertyName("jpeg_estimator_score")]
    public double JpegEstimatorScore { get; init; }
    
    [JsonPropertyName("noisy_score")]
    public double NoisyScore { get; init; }
    
    [JsonPropertyName("overall_quality")]
    public double OverallQuality { get; init; }
}

public record ModerationInfo
{
    [JsonPropertyName("has_paddings")]
    public bool HasPaddings { get; init; }
}
