﻿using System.Text;
using System.Text.Json;
using HC.AiProcessor.Application.Constants;
using HC.AiProcessor.Application.Models;
using HC.Packages.Common.Contracts.V1;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace HC.AiProcessor.Application.Clients;

public class SerperClient(
    IHttpClientFactory httpClientFactory,
    IOptions<ImageToolClientSettings> settings,
    ILogger<SerperClient> logger)
{
    private readonly HttpClient _httpClient = httpClientFactory.CreateClient(WellKnownHttpClients.SerperClient);
    private readonly SerperClientOptions _serperClientConfig = settings.Value.Serper;

    public async Task<IReadOnlyDictionary<string, IEnumerable<ImageItem>>> GetImagesAsync(
        string[] productTitles,
        CancellationToken cancellationToken = default)
    {
        var payload = productTitles.Select(title =>
        {
            var foo = new
            {
                q = title,
                gl = _serperClientConfig.Country,
                num = 20
            };
            return foo;
        });
        using (logger.BeginScope("Serper AI processing for {titles}", string.Join(',', productTitles)))
        {
            var json = JsonSerializer.Serialize(payload);
            using var content = new StringContent(json, Encoding.UTF8, "application/json");
            HttpResponseMessage response;
            try
            {
                response = await _httpClient.PostAsync("/images", content, cancellationToken);
            }
            catch (Exception ex)
            {
                logger.LogWarning(ex, "Connection issue with Serper API : {Message}", ex.Message);
                throw new MicroserviceApiException(
                    $"Error with connection to the Serper API: {ex.Message}",
                    StatusCodes.Status502BadGateway,
                    "/images",
                    "Serper API",
                    null);
            }
        
            if (!response.IsSuccessStatusCode)
            {
                var errorContent = await response.Content.ReadAsStringAsync(cancellationToken);
                logger.LogWarning("The Serper API returned an error {StatusCode}: {ErrorContent}",
                    (int)response.StatusCode, errorContent);
                throw new MicroserviceApiException(
                    $"The Serper API returned an error {(int)response.StatusCode}: {errorContent}",
                    (int)response.StatusCode,
                    "/images",
                    "Serper API",
                    null);
            }
        
            await using var stream = await response.Content.ReadAsStreamAsync(cancellationToken);
            var results = await JsonSerializer.DeserializeAsync<SearchResultDto[]>(stream, cancellationToken: cancellationToken)
                          ?? [];
            var dict = results
                .Where(r => r.Images is { Count: > 0 })
                .ToDictionary(
                    r => r.SearchParametersDto.Query, IEnumerable<ImageItem> (r) => r.Images.Select(img =>
                            new ImageItem(img.ImageUrl, img.Title, img.Width, img.Height))
                        .ToArray(),
                    StringComparer.OrdinalIgnoreCase);
 
            return dict;
        }
    }
}

public readonly record struct ImageItem(
    string Url,
    string Title,
    int Width,
    int Height)
{
    public double AspectRatio
    {
        get
        {
            if (Width == 0 || Height == 0) return 0d;
            return Width >= Height 
                ? (double)Width / Height 
                : (double)Height / Width;
        }
    }

    public int Size =>  Width * Height;
}

internal sealed record ImageDto(
    [property: JsonPropertyName("imageUrl")]
    string ImageUrl,
    [property: JsonPropertyName("title")]
    string Title,
    [property: JsonPropertyName("imageWidth")]
    int Width,
    [property: JsonPropertyName("imageHeight")]
    int Height);

internal sealed record SearchParametersDto(
    [property: JsonPropertyName("q")]
    string Query);

internal sealed record SearchResultDto(
    [property: JsonPropertyName("searchParameters")]
    SearchParametersDto SearchParametersDto,
    [property: JsonPropertyName("images")] IReadOnlyList<ImageDto> Images);


