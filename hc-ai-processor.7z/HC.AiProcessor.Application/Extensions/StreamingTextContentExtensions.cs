﻿using Microsoft.SemanticKernel;

namespace HC.AiProcessor.Application.Extensions;

internal static class StreamingTextContentExtensions
{
    public static bool IsLastPart(this StreamingTextContent textContent)
    {
        if (textContent.Text == null &&
            textContent.Metadata is not null &&
            textContent.Metadata.TryGetValue("FinishReason", out object? finishReason) &&
            "Stop".Equals(finishReason))
        {
            return true;
        }

        return false;
    }
}
