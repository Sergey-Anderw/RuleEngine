﻿using System.IO.Abstractions;
using System.Net.Http.Headers;
using FluentValidation;
using HC.AiProcessor.Application.Clients;
using HC.AiProcessor.Application.Clients.ChatGPT;
using HC.AiProcessor.Application.Clients.ClaidAi;
using HC.AiProcessor.Application.Constants;
using HC.AiProcessor.Application.Models;
using HC.AiProcessor.Application.Services;
using HC.Packages.Common.Behaviors;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Options;
using Polly;
using Serilog;
using Serilog.Settings.Configuration;

namespace HC.AiProcessor.Application.Extensions;

public static class HostApplicationBuilderExtensions
{
    public static T AddAndConfigureLogging<T>(this T builder) where T : IHostApplicationBuilder
    {
        Log.Logger = new LoggerConfiguration().ReadFrom
            .Configuration(builder.Configuration, (ConfigurationReaderOptions) null).CreateLogger();
        builder.Services.AddSerilog();
        return builder;
    }

    public static T AddAndConfigureMediatR<T>(this T builder) where T : IHostApplicationBuilder
    {
        builder.Services.AddMediatR(cfg =>
            cfg.RegisterServicesFromAssembly(typeof(HostApplicationBuilderExtensions).Assembly));
        //builder.Services.AddScoped(typeof(IPipelineBehavior<,>), typeof(ValidateClientPipelineBehavior<,>));

        return builder;
    }

    public static T AddAndConfigureServices<T>(this T builder) where T : IHostApplicationBuilder
    {
        builder.Services
            .AddHttpClient(WellKnownHttpClients.AiClient)
            .ConfigureHttpClient((sp, client) =>
            {
                var cfg = sp.GetRequiredService<IOptions<AiProcessorConfig>>().Value;
                client.Timeout = TimeSpan.FromSeconds(cfg.OpenAiClientTimeoutInSeconds);
            })
            //.AddPolicyHandler(RecordRetryPolicy())
            .ConfigurePrimaryHttpMessageHandler(() =>
            {
                var handler = new HttpClientHandler();
                handler.ServerCertificateCustomValidationCallback = (_, _, _, _) => true;
                return handler;
            });

        builder.Services
            .AddHttpClient(WellKnownHttpClients.SerperClient)
            .ConfigureHttpClient((sp, client) =>
            {
                var cfg = sp.GetRequiredService<IOptions<ImageToolClientSettings>>().Value;
                client.BaseAddress = new Uri(cfg.Serper.Url);
                client.DefaultRequestHeaders.Add("X-API-KEY", cfg.Serper.ApiKey);
            });

        builder.Services
            .AddHttpClient(WellKnownHttpClients.DeWatermarkClient)
            .ConfigureHttpClient((sp, client) =>
            {
                var cfg = sp.GetRequiredService<IOptions<ImageToolClientSettings>>().Value;
                client.BaseAddress = new Uri(cfg.DeWatermarkAi.Url);
                client.DefaultRequestHeaders.Add("X-API-KEY", cfg.DeWatermarkAi.ApiKey);
            });

        builder.Services
            .AddHttpClient(WellKnownHttpClients.ClaidAiClient)
            .ConfigureHttpClient((sp, client) =>
            {
                var cfg = sp.GetRequiredService<IOptions<ImageToolClientSettings>>().Value;
                client.BaseAddress = new Uri(cfg.ClaidAi.Url);
                client.DefaultRequestHeaders.Authorization =
                    new AuthenticationHeaderValue("Bearer", cfg.ClaidAi.ApiKey);
            });

        builder.Services
            .AddHttpClient("ImagesVerificationClient")
            .SetHandlerLifetime(TimeSpan.FromMinutes(10))
            .ConfigurePrimaryHttpMessageHandler(() => new SocketsHttpHandler
            {
                PooledConnectionLifetime = TimeSpan.FromMinutes(5),
                MaxConnectionsPerServer = 128
            })
            .AddPolicyHandler(Policy.TimeoutAsync<HttpResponseMessage>(TimeSpan.FromSeconds(5)));

        builder.Services.AddSingleton<IAiTranslationService, ChatGptTranslationService>();
        builder.Services.AddSingleton<IAiStreamingTranslationService, ChatGptStreamingTranslationService>();
        builder.Services.AddSingleton<IAiRephrasingService, ChatGptRephrasingService>();
        builder.Services.AddSingleton<IAiStreamingRephrasingService, ChatGptStreamingRephrasingService>();
        builder.Services.AddSingleton<IAiGenerationService, ChatGptGenerationService>();
        builder.Services.AddSingleton<IAiAttributesPopulationService, ChatGptAttributesPopulationService>();
        builder.Services.AddSingleton<IAiEmbeddingService, ChatGptEmbeddingService>();
        builder.Services.AddSingleton<IAiProcessorFilesExtractItemsService, AiProcessorFilesExtractItemsService>();
        builder.Services.AddSingleton<ITemplateEngine, FluidTemplateEngine>();
        builder.Services.AddSingleton<IAiEmbeddingCache, AiEmbeddingCache>();
        builder.Services.AddSingleton<ITextGenerationServiceFactory, TextGenerationServiceFactory>();
        builder.Services.AddSingleton<ITextEmbeddingGenerationServiceFactory, TextEmbeddingGenerationServiceFactory>();
        builder.Services.AddTransient<ChatGPTClient>();
        builder.Services.AddTransient<SerperClient>();
        builder.Services.AddTransient<DeWatermarkAiClient>();
        builder.Services.AddTransient<ClaidAiClient>();
        builder.Services.AddScoped<ISearchImagesService, MagicImageService>();
        builder.Services.AddScoped<IImageEditService, MagicImageEditService>();
        builder.Services.AddTransient<IStorageService, StorageService>();
        builder.Services.AddTransient(typeof(IPipelineBehavior<,>), typeof(ValidationBehavior<,>));
        builder.Services.AddValidatorsFromAssembly(Assembly.GetExecutingAssembly());
        builder.Services.AddSingleton<ICpuBoundBatchProcessor, DataflowBatchProcessor>();
        builder.Services.AddSingleton<IAiTextGenerationInputBatchProcessor, AiTextGenerationInputBatchProcessor>();
        builder.Services.AddSingleton<IFileSystem, FileSystem>();
        builder.Services.AddSingleton<IRandomIdGenerator, RandomIdGenerator>();
        builder.Services.AddSingleton<IAiTextGenerationInputProcessor, AiTextGenerationInputProcessor>();

        return builder;
    }
}
