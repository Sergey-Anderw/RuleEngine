﻿using System.Text.RegularExpressions;

namespace HC.AiProcessor.Application.Extensions;

public static class StringExtensions
{
    public static string ProcessTemplate(this string? template, object obj)
    {
        if (string.IsNullOrEmpty(template))
            return "";
        var paramsExp = new Regex("{[^{}]+}");
        var matches = paramsExp
            .Matches(template)
            .Select(x => x.Value)
            .Distinct()
            .ToList();
        if (!matches.Any())
            return template;

        Dictionary<string, string> values = new();
        Type paramType = obj.GetType();
        foreach (var match in matches)
        {
            var property = paramType.GetProperty(match.Trim('}', '{'));
            if (property is null)
                continue;
            values[match] = property.GetValue(obj)?.ToString() ?? "";
        }

        var result = values?
                    .Aggregate(template, (t, v) => t.Replace("{" + v.Key + "}", v.Value))
                ?? template;

        return result;
    }

    public static string ProcessTemplate(this string? template, Dictionary<string, object> objs)
    {
        if (string.IsNullOrEmpty(template))
            return "";
        var paramsExp = new Regex("{[^{}]+}");
        var matches = paramsExp
            .Matches(template)
            .Select(x => x.Value)
            .Distinct()
            .ToList();
        if (!matches.Any())
            return template;

        Dictionary<string, string> values = new();
        foreach (var match in matches)
        {
            var parts = match.Trim('}', '{').Split('.');
            if (parts.Length == 1)
            {
                if (objs.TryGetValue(parts.First(), out var obj))
                    values[match] = obj?.ToString() ?? "";
            }
            else
            {
                var it = parts.GetEnumerator();
                it.MoveNext();
                if (objs.TryGetValue((string)it.Current, out var obj))
                {

                    while (it.MoveNext() && obj is not null)
                    {
                        var propertyInfo = obj.GetType().GetProperty((string)it.Current);
                        if (propertyInfo is null)
                        {
                            obj = null;
                            break;
                        }
                        obj = propertyInfo.GetValue(obj);
                    }

                    values[match] = obj?.ToString() ?? "";
                }
            }
        }

        var result = values?
                    .Aggregate(template, (t, v) => t.Replace(v.Key, v.Value))
                ?? template;

        return result;
    }
}
