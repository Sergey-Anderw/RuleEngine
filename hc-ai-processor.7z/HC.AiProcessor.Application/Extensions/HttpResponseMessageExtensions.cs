﻿using System.Net;

namespace HC.AiProcessor.Application.Extensions;

public static class HttpResponseMessageExtensions
{
    public static bool IsImageOk(this HttpResponseMessage resp)
    {
        var okStatus = resp.StatusCode is HttpStatusCode.OK
            or HttpStatusCode.PartialContent
            or HttpStatusCode.RequestedRangeNotSatisfiable;

        if (!okStatus)
            return false;

        var mediaType = resp.Content.Headers.ContentType?.MediaType;
        if (mediaType is null || !mediaType.StartsWith("image/", StringComparison.OrdinalIgnoreCase))
            return false;
        
        var length = resp.Content.Headers.ContentLength;
        return length is null or > 0;

    }
}
