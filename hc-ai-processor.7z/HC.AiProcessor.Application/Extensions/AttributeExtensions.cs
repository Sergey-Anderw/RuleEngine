﻿using System.Text.Json;
using System.Text.Json.Nodes;
using HC.AiProcessor.Entity.Catalog;
using HC.Packages.Catalog.Contracts.V1.Enums;
using HC.Packages.Persistent.Entities;
using HC.Packages.Persistent.Helpers;
using Attribute = HC.AiProcessor.Entity.Catalog.Attribute;

namespace HC.AiProcessor.Application.Extensions;

public static class AttributeExtensions
{
    public static string GetLabel(this Attribute attribute, string locale)
    {
        string result = attribute.Name.GetValue(locale)?.ToString() ?? attribute.Code;
        return result;
    }

    public static string GetValue(
        this Attribute attribute,
        JsonValueStructure jsonValueStructure,
        string? locale = null,
        string? channel = null)
    {
        object? value = jsonValueStructure.GetValue(
            locale: attribute.ValuePerLocale ? locale : null,
            channel: attribute.ValuePerChannel ? channel : null);

        if (value is null)
            return string.Empty;

        switch (attribute.ValueType)
        {
            case AttributeValueTypeEnum.Bool:
            {
                return value.ToString() == "true" ? "true" : "false";
            }
            case AttributeValueTypeEnum.IntegerNumber:
            case AttributeValueTypeEnum.RealNumber:
            case AttributeValueTypeEnum.Text:
            case AttributeValueTypeEnum.RichText:
            case AttributeValueTypeEnum.Date:
            {
                return value.ToString()!;
            }
            case AttributeValueTypeEnum.DateRange:
            {
                if (value is not JsonElement { ValueKind: JsonValueKind.Object } jsonElement)
                    return string.Empty;

                var jsonObject = jsonElement.Deserialize<JsonObject>()!;
                const string fromKey = "from";
                const string toKey = "to";

                if (!jsonObject.ContainsKey(fromKey) && !jsonObject.ContainsKey(toKey))
                    return string.Empty;

                jsonObject.TryGetPropertyValue(fromKey, out JsonNode? from);
                jsonObject.TryGetPropertyValue(toKey, out JsonNode? to);

                return $"{from ?? string.Empty} - {to ?? string.Empty}";
            }
            case AttributeValueTypeEnum.Select:
            {
                if ((attribute.Settings?.Data?.Options?.Count ?? 0) == 0)
                    return string.Empty;

                string? displayValue = null;

                foreach (JsonAttributeSettingsOptionItemStructure option in attribute.Settings!.Data!.Options!)
                {
                    if (option.Code == value.ToString())
                    {
                        displayValue = option
                                .GetValue(locale)?
                                .ToString() ?? $"[{option.Code}]";
                        break;
                    }

                    string dataValue = option
                            .GetValue(locale)?
                            .ToString() ?? $"[{option.Code}]";

                    if (dataValue == value.ToString())
                    {
                        displayValue = dataValue;
                        break;
                    }
                }

                return displayValue ?? string.Empty;
            }
            case AttributeValueTypeEnum.MultiSelect:
            {
                if ((attribute.Settings?.Data?.Options?.Count ?? 0) == 0)
                    return string.Empty;

                if (value is not JsonElement jsonElement || jsonElement.ValueKind != JsonValueKind.Array)
                    return string.Empty;

                var jsonArray = jsonElement.Deserialize<JsonArray>()!;

                if (jsonArray.Count == 0)
                    return string.Empty;

                var displayValues = new List<string>();
                List<string> values = jsonArray
                    .Select(x => x!.ToString())
                    .ToList();

                foreach (JsonAttributeSettingsOptionItemStructure option in attribute.Settings!.Data!.Options!)
                {
                    if (values.Contains(option.Code))
                    {
                        displayValues.Add(option.GetValue(locale)?.ToString() ?? $"[{option.Code}]");
                        continue;
                    }

                    string dataValue = option.GetValue(locale)?.ToString() ?? $"[{option.Code}]";

                    if (values.Contains(dataValue))
                    {
                        displayValues.Add(dataValue);
                    }
                }

                string displayValue = string.Join(", ", displayValues);
                return displayValue;
            }
            case AttributeValueTypeEnum.StringArray:
            {
                if (value is not JsonElement { ValueKind: JsonValueKind.Array } jsonElement)
                    return string.Empty;

                var jsonArray = jsonElement.Deserialize<JsonArray>()!;

                if (jsonArray.Count == 0)
                    return string.Empty;

                IEnumerable<string> values = jsonArray
                    .Select(x => x!.ToString())
                    .Where(x => !string.IsNullOrWhiteSpace(x));

                string displayValue = string.Join(", ", values);
                return displayValue;
            }
            default:
                return string.Empty;
        }
    }

    public static bool IsValueEmpty(
        this Attribute attribute,
        JsonValueStructure jsonValueStructure,
        string? locale = null,
        string? channel = null)
    {
        string value = attribute.GetValue(
            jsonValueStructure,
            locale,
            channel);

        switch (attribute.ValueType)
        {
            case AttributeValueTypeEnum.Bool:
                return string.IsNullOrWhiteSpace(value) || "false".Equals(value);
            case AttributeValueTypeEnum.RichText:
                return string.IsNullOrWhiteSpace(value) || "<br>".Equals(value);
            default:
                return string.IsNullOrWhiteSpace(value);
        }
    }

    public static string? GetDescription(this Attribute attribute, string locale)
    {
        string? result = attribute.Guidelines.GetValue(locale)?.ToString();
        return result;
    }

    private static object? GetValue(
        this JsonAttributeSettingsOptionItemStructure data,
        string? locale = null,
        string? channel = null)
    {
        return new JsonValueStructure { Data = data.Value }.GetValue(locale, channel);
    }
}
