﻿namespace HC.AiProcessor.Application.Models;

public sealed record AiTextGenerationOutput
{
    public string? Content { get; init; }
}
