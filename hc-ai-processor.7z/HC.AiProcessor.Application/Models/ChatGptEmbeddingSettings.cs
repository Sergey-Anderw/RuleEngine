﻿namespace HC.AiProcessor.Application.Models;

public record ChatGptEmbeddingSettings
{
}
