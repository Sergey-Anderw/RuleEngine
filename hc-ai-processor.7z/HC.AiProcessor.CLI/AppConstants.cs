﻿namespace HC.AiProcessor.CLI;

internal static class AppConstants
{
    public const int SuccessCode = 0;
    public const int FailCode = -1;
}
