﻿namespace HC.AiProcessor.Entity.Ai.Enums;

public enum AiSettingsStatusType
{
    Enabled = 1,
    Disabled = 2
}
