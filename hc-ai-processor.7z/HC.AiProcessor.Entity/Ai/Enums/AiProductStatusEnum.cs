﻿namespace HC.AiProcessor.Entity.Ai.Enums;

public enum AiProductStatusEnum
{
    Published = 0,
    Draft = 1
}
