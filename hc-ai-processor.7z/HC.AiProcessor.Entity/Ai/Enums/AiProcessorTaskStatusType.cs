﻿namespace HC.AiProcessor.Entity.Ai.Enums;

public enum AiProcessorTaskStatusType
{
    Queued,
    InProgress,
    Success,
    Failed
}
