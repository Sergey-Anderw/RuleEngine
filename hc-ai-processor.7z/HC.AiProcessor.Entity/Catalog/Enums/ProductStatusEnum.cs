﻿namespace HC.AiProcessor.Entity.Catalog.Enums;

public enum ProductStatusEnum
{
    Published = 0,
    Draft = 1
}
